# flash_cc2531
flash CC2531 USB dongle from your Raspberry, without Arduino nor CC Debugger.
Works also for CC2530.

CC2531 is probably the cheapest option to control zigbee devices from your raspberry with open source software like [domoticz](https://www.domoticz.com/) or [Home assistant](https://www.home-assistant.io/hassio/).

**[Read the documentation for more details](https://jmichault.github.io/flash_cc2531-dok/)**

You should also consult [zigbee2mqtt documentation](https://www.zigbee2mqtt.io/)

This project is licensed under the GPL v3 license (see COPYING).

